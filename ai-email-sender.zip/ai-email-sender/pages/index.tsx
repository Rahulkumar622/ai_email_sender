import { useState } from 'react';
import Head from 'next/head';

export default function Home() {
  const [recipients, setRecipients] = useState('');
  const [prompt, setPrompt] = useState('');
  const [subject, setSubject] = useState('AI-Generated Email');
  const [emailBody, setEmailBody] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleGenerate = async () => {
    setLoading(true);
    setMessage('');
    const res = await fetch('/api/generate', {
      method: 'POST',
      body: JSON.stringify({ prompt }),
    });
    const data = await res.json();
    setEmailBody(data.email);
    setLoading(false);
  };

  const handleSend = async () => {
    setLoading(true);
    const res = await fetch('/api/send', {
      method: 'POST',
      body: JSON.stringify({ recipients, subject, body: emailBody }),
    });
    const data = await res.json();
    setMessage(data.message);
    setLoading(false);
  };

  return (
    <>
      <Head>
        <title>AI Email Sender</title>
      </Head>

      <main className="wrapper">
        <div className="card">
          <h1>📨 AI Email Sender</h1>

          <input
            type="text"
            placeholder="Recipients (comma separated)"
            value={recipients}
            onChange={(e) => setRecipients(e.target.value)}
          />

          <input
            type="text"
            placeholder="Subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />

          <textarea
            placeholder="Prompt for the email"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />

          <button className="generate" onClick={handleGenerate} disabled={loading}>
            ✨ Generate Email
          </button>

          <textarea
            value={emailBody}
            onChange={(e) => setEmailBody(e.target.value)}
          />

          <button className="send" onClick={handleSend} disabled={loading}>
            📤 Send Email
          </button>

          {message && <div className="message">{message}</div>}
        </div>
      </main>

      <style jsx>{`
        body {
          margin: 0;
        }

        .wrapper {
          min-height: 100vh;
          background: linear-gradient(135deg, #6e8efb, #a777e3);
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 2rem;
        }

        .card {
          width: 100%;
          max-width: 700px;
          background: rgba(255, 255, 255, 0.12);
          box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border-radius: 20px;
          padding: 2rem;
          color: #fff;
          font-family: 'Segoe UI', sans-serif;
        }

        h1 {
          text-align: center;
          font-size: 2rem;
          margin-bottom: 1.5rem;
        }

        input,
        textarea {
          width: 100%;
          padding: 12px;
          margin-bottom: 1rem;
          border: none;
          border-radius: 12px;
          font-size: 1rem;
          box-sizing: border-box;
          outline: none;
          background: rgba(255, 255, 255, 0.2);
          color: #fff;
        }

        input::placeholder,
        textarea::placeholder {
          color: #ccc;
        }

        textarea {
          resize: vertical;
          min-height: 100px;
        }

        button {
          width: 100%;
          padding: 12px;
          margin-top: 0.5rem;
          font-size: 1rem;
          border: none;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .generate {
          background: #00c9ff;
          background: linear-gradient(to right, #92fe9d, #00c9ff);
          color: #000;
        }

        .generate:hover {
          opacity: 0.9;
          transform: scale(1.02);
        }

        .send {
          background: #ff758c;
          background: linear-gradient(to right, #ff7eb3, #ff758c);
          color: #fff;
        }

        .send:hover {
          opacity: 0.95;
          transform: scale(1.02);
        }

        .message {
          margin-top: 1rem;
          padding: 12px;
          background-color: rgba(76, 175, 80, 0.2);
          color: #d0ffd0;
          border: 1px solid #9ccc65;
          border-radius: 12px;
          text-align: center;
        }
      `}</style>
    </>
  );
}
